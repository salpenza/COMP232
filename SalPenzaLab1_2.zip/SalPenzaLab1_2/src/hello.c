/**
* Name: Sal Penza
* Lab: Lab 1
* Date: 1/29/20
**/
#include <stdio.h>

int main(void) {
    int x = 0;
    printf("Hello World. \n \t and you ! \n ");
    /* print out a message */

    return 0;
}

