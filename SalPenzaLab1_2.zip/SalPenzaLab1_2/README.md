# COMP 232 Lab 1

Sal Penza

1/29/20

## Task 1

### Description

Ran hello.c a few different ways in order to setup and test the environment.

### Sample Runs

```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/hello
Hello World. 
 	 and you ! 
 
Process finished with exit code 0
```

## Task 2

### Description

Added another variable for faculty members as a float. Asked the user for the number of faculty members using a print statement and stored the input in the faculty variable using scanf. Created a ratio variable and assigned the Students divided by the faculty members to it. Lastly used a printf statement to print the ratio of students to faculty.

### Sample Runs
```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/types
How many students does CSUCI have ?:14
CSUCI has 14 students.

Process finished with exit code 0
```
```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/types
How many students does CSUCI have ?:67
How many faculty members does CSUCI have ?:5
The ratio of students to faculty at CSUCI is 13.4. 

Process finished with exit code 0
```
```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/types
How many students does CSUCI have ?:16
How many faculty members does CSUCI have ?:4
The ratio of students to faculty at CSUCI is 4.0. 

Process finished with exit code 0
```
```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/types
How many students does CSUCI have ?:17
How many faculty members does CSUCI have ?:12
The ratio of students to faculty at CSUCI is 1.4. 

Process finished with exit code 0
```

## Task 3

### Description

Converted level to a char and asked the user for a character input. Stored the input in the level variable using getchar(). Created a switch statement where the conditional statement is the level variable. I used tolower() in order to ensure that level was a lowercase character and created mutliple cases using puts() for output.

### Sample Runs

```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/if-then-else
Enter a character (e, f, or h): 1
Error, invalid input

Process finished with exit code 0
```
```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/if-then-else
Enter a character (e, f, or h): e
empty

Process finished with exit code 0
```
```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/if-then-else
Enter a character (e, f, or h): f
full

Process finished with exit code 0
```
```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/if-then-else
Enter a character (e, f, or h): h
half full

Process finished with exit code 0
```
```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/if-then-else
Enter a character (e, f, or h): a
Error, invalid input

Process finished with exit code 0
```

```
/Users/salvatore.penza568/Desktop/COMP_232/c_tut/cmake-build-debug/if-then-else
Enter a character (e, f, or h): H
half full

Process finished with exit code 0
```
## Task 4

### Description
desc

### Sample Runs
